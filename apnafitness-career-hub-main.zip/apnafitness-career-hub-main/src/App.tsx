
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Jobs from "./pages/Jobs";
import Pricing from "./pages/Pricing";
import TrainerRegister from "./pages/TrainerRegister";
import About from "./pages/About";
import MeetFounder from "./pages/MeetFounder";
import Login from "./pages/Login";
import PostJob from "./pages/PostJob";
import TrainerDashboard from "./pages/TrainerDashboard";
import HRPortal from "./pages/HRPortal";
import ForgotPassword from "./pages/ForgotPassword";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/register/trainer" element={<TrainerRegister />} />
          <Route path="/about" element={<About />} />
          <Route path="/meet-founder" element={<MeetFounder />} />
          <Route path="/login" element={<Login />} />
          <Route path="/post-job" element={<PostJob />} />
          <Route path="/trainer-dashboard" element={<TrainerDashboard />} />
          <Route path="/hr-portal" element={<HRPortal />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
