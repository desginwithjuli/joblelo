
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Target, Eye, Heart, Users, Award, Zap } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';

const About = () => {
  const coreValues = [
    {
      icon: <Target className="h-8 w-8" />,
      title: "Excellence",
      description: "We strive for excellence in everything we do, from platform functionality to customer service."
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Passion for Fitness",
      description: "Our deep love for fitness drives us to create meaningful connections in the industry."
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Community First",
      description: "We believe in building a strong, supportive community of fitness professionals."
    },
    {
      icon: <Award className="h-8 w-8" />,
      title: "Quality Assurance",
      description: "We maintain high standards for both trainers and gym partners on our platform."
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Innovation",
      description: "We continuously innovate to improve the fitness career experience."
    },
    {
      icon: <Eye className="h-8 w-8" />,
      title: "Transparency",
      description: "We believe in honest, transparent relationships with all our stakeholders."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Breadcrumb */}
      <div className="bg-gray-50 py-4">
        <div className="container mx-auto px-4">
          <Link to="/" className="flex items-center text-blue-600 hover:text-blue-800">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-6">About ApnaFitness</h1>
          <p className="text-xl mb-8 text-blue-100 max-w-3xl mx-auto">
            Revolutionizing the fitness industry by connecting passionate trainers with leading gyms 
            across Delhi, Ghaziabad, and Noida
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-800 mb-8 text-center">Our Story</h2>
            <div className="space-y-6 text-gray-700 leading-relaxed text-lg">
              <p>
                ApnaFitness was born from a simple yet powerful observation: the fitness industry in 
                Delhi NCR was facing a significant challenge. Talented, certified fitness trainers 
                were struggling to find the right career opportunities, while gym owners and fitness 
                centers were finding it difficult to recruit qualified professionals.
              </p>
              <p>
                Founded with the vision of bridging this gap, ApnaFitness has become the premier 
                platform for fitness career opportunities in the National Capital Region. We understand 
                that fitness is not just about physical well-being; it's about building careers, 
                creating communities, and transforming lives.
              </p>
              <p>
                Today, we proudly serve hundreds of fitness professionals and partner with leading 
                gyms and fitness centers across Delhi, Ghaziabad, and Noida. Our AI-driven matching 
                system ensures that trainers find opportunities that truly match their skills and 
                aspirations, while gym owners discover talent that aligns with their requirements.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Meet Our Founder Section */}
      <section id="founder" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">Meet Our Founder</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left">
                <img
                  src="/lovable-uploads/b5f06ecd-c8e1-4c02-8f84-8c3a882741b1.png"
                  alt="Roshan Gupta - Founder of ApnaFitness"
                  className="w-64 h-64 object-cover rounded-full shadow-xl mx-auto lg:mx-0"
                />
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-3xl font-bold text-gray-800 mb-2">Roshan Gupta</h3>
                  <p className="text-xl text-blue-600 font-semibold">Founder & CEO</p>
                </div>
                
                <div className="space-y-4 text-gray-700 leading-relaxed">
                  <p>
                    With a Bachelor's degree in Computer Applications (BCA), Roshan Gupta combines 
                    technical expertise with entrepreneurial vision. His passion for fitness and 
                    technology led him to create ApnaFitness - a platform that addresses real 
                    challenges in the fitness industry.
                  </p>
                  <p>
                    "Every fitness professional deserves the opportunity to build a meaningful career. 
                    ApnaFitness exists to make that vision a reality," says Roshan.
                  </p>
                </div>
                
                <Link to="/meet-founder">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Read Full Story
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">Mission & Vision</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-8">
                <div className="flex items-center mb-6">
                  <Target className="h-12 w-12 text-blue-600 mr-4" />
                  <h3 className="text-2xl font-bold text-blue-600">Our Mission</h3>
                </div>
                <p className="text-gray-700 leading-relaxed text-lg">
                  To revolutionize the fitness industry by creating a seamless, AI-powered platform 
                  that connects talented fitness professionals with leading gyms and fitness centers, 
                  enabling career growth and ensuring quality fitness services across Delhi NCR.
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-8">
                <div className="flex items-center mb-6">
                  <Eye className="h-12 w-12 text-green-600 mr-4" />
                  <h3 className="text-2xl font-bold text-green-600">Our Vision</h3>
                </div>
                <p className="text-gray-700 leading-relaxed text-lg">
                  To become India's most trusted fitness career platform, where every fitness 
                  professional finds their ideal opportunity and every gym discovers exceptional 
                  talent, ultimately contributing to a healthier and fitter society.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-800 mb-12 text-center">Our Core Values</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {coreValues.map((value, index) => (
                <div key={index} className="bg-white rounded-lg shadow-lg p-6 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-green-500 to-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Join Our Community?</h2>
          <p className="text-xl mb-8 text-green-100">
            Be part of the fitness revolution in Delhi NCR
          </p>
          <div className="flex justify-center space-x-4">
            <Link to="/register/trainer">
              <Button className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3">
                Join as Trainer
              </Button>
            </Link>
            <Link to="/register/gym">
              <Button variant="outline" className="border-white text-white hover:bg-white hover:text-green-600 px-8 py-3">
                Partner with Us
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
