
import React, { useState } from 'react';
import { User, Briefcase, Star, MapPin, Calendar, Bell, Settings, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const TrainerDashboard = () => {
  const [activeTab, setActiveTab] = useState('profile');

  // Mock data for the trainer
  const trainerData = {
    name: 'Roshan Gupta',
    email: 'energiegymmarketing@gmail.com',
    phone: '+919631005476',
    username: 'Roshan_Gupta_1234',
    experience: '2-5 years',
    skills: ['Personal Training', 'Yoga', 'Pilates', 'Nutrition Counseling'],
    preferredLocations: ['Delhi'],
    verified: true
  };

  const appliedJobs = [
    {
      id: 1,
      title: 'Personal Trainer',
      gym: 'Gold\'s Gym',
      location: 'Ghaziabad, Indirapuram',
      salary: '₹25,000-₹45,000',
      status: 'Under Review',
      appliedDate: '2025-06-03'
    },
    {
      id: 2,
      title: 'Yoga Instructor',
      gym: '21 Fitness',
      location: 'Delhi, Saket',
      salary: '₹20,000-₹30,000',
      status: 'Shortlisted',
      appliedDate: '2025-06-02'
    }
  ];

  const recommendedJobs = [
    {
      id: 3,
      title: 'Pilates Instructor',
      gym: 'Energie Gym',
      location: 'Noida, Sector 18',
      salary: '₹28,000-₹38,000',
      matchScore: 95
    },
    {
      id: 4,
      title: 'Nutrition Counselor',
      gym: 'Cult Fit',
      location: 'Delhi, Connaught Place',
      salary: '₹30,000-₹50,000',
      matchScore: 88
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">{trainerData.name}</h3>
                <p className="text-gray-600">@{trainerData.username}</p>
                {trainerData.verified && (
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 mt-2">
                    <Star className="h-3 w-3 mr-1" />
                    Verified Trainer
                  </span>
                )}
              </div>
              
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center px-4 py-2 rounded-lg transition-colors ${
                    activeTab === 'profile' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <User className="h-5 w-5 mr-3" />
                  My Profile
                </button>
                <button
                  onClick={() => setActiveTab('jobs')}
                  className={`w-full flex items-center px-4 py-2 rounded-lg transition-colors ${
                    activeTab === 'jobs' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Briefcase className="h-5 w-5 mr-3" />
                  Applied Jobs
                </button>
                <button
                  onClick={() => setActiveTab('recommended')}
                  className={`w-full flex items-center px-4 py-2 rounded-lg transition-colors ${
                    activeTab === 'recommended' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Star className="h-5 w-5 mr-3" />
                  Recommended
                </button>
                <button
                  onClick={() => setActiveTab('alerts')}
                  className={`w-full flex items-center px-4 py-2 rounded-lg transition-colors ${
                    activeTab === 'alerts' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Bell className="h-5 w-5 mr-3" />
                  Job Alerts
                </button>
                <button className="w-full flex items-center px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors">
                  <Settings className="h-5 w-5 mr-3" />
                  Settings
                </button>
                <button className="w-full flex items-center px-4 py-2 rounded-lg text-red-600 hover:bg-red-50 transition-colors">
                  <LogOut className="h-5 w-5 mr-3" />
                  Logout
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'profile' && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">My Profile</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <input
                      type="text"
                      value={trainerData.name}
                      className="w-full border border-gray-300 rounded-md px-3 py-2"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input
                      type="email"
                      value={trainerData.email}
                      className="w-full border border-gray-300 rounded-md px-3 py-2"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input
                      type="text"
                      value={trainerData.phone}
                      className="w-full border border-gray-300 rounded-md px-3 py-2"
                      readOnly
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Experience</label>
                    <input
                      type="text"
                      value={trainerData.experience}
                      className="w-full border border-gray-300 rounded-md px-3 py-2"
                      readOnly
                    />
                  </div>
                </div>

                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Skills</label>
                  <div className="flex flex-wrap gap-2">
                    {trainerData.skills.map((skill, index) => (
                      <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Locations</label>
                  <div className="flex flex-wrap gap-2">
                    {trainerData.preferredLocations.map((location, index) => (
                      <span key={index} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        {location}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-8">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Edit Profile
                  </Button>
                </div>
              </div>
            )}

            {activeTab === 'jobs' && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Applied Jobs</h2>
                
                <div className="space-y-4">
                  {appliedJobs.map((job) => (
                    <div key={job.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-800">{job.title}</h3>
                          <p className="text-gray-600">{job.gym}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          job.status === 'Shortlisted' ? 'bg-green-100 text-green-800' :
                          job.status === 'Under Review' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {job.status}
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600 space-x-4">
                        <span className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {job.location}
                        </span>
                        <span>{job.salary}</span>
                        <span className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          Applied: {job.appliedDate}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'recommended' && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Recommended Jobs</h2>
                
                <div className="space-y-4">
                  {recommendedJobs.map((job) => (
                    <div key={job.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-800">{job.title}</h3>
                          <p className="text-gray-600">{job.gym}</p>
                        </div>
                        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                          {job.matchScore}% Match
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-gray-600 space-x-4">
                          <span className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {job.location}
                          </span>
                          <span>{job.salary}</span>
                        </div>
                        <Button className="bg-blue-600 hover:bg-blue-700">
                          Apply Now
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'alerts' && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Job Alert Preferences</h2>
                
                <div className="space-y-6">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Email Notifications</h3>
                    <div className="space-y-3">
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded mr-3" defaultChecked />
                        <span>New job matches based on my skills</span>
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded mr-3" defaultChecked />
                        <span>Application status updates</span>
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="rounded mr-3" />
                        <span>Weekly job digest</span>
                      </label>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Job Alert Filters</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Salary Range</label>
                        <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                          <option>₹20,000 - ₹30,000</option>
                          <option>₹30,000 - ₹40,000</option>
                          <option>₹40,000 - ₹50,000</option>
                          <option>₹50,000+</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Alert Frequency</label>
                        <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                          <option>Immediately</option>
                          <option>Daily</option>
                          <option>Weekly</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Save Preferences
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default TrainerDashboard;
