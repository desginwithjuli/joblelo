
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Linkedin, Twitter, Mail, Award, Users, Target, CheckCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';

const MeetFounder = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Breadcrumb */}
      <div className="bg-gray-50 py-4 border-b">
        <div className="container mx-auto px-4">
          <Link to="/" className="flex items-center text-blue-600 hover:text-blue-800 transition-colors">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">Leadership Excellence</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Meet the visionary leader who is transforming the fitness industry through innovation and technology
            </p>
          </div>
        </div>
      </section>

      {/* Founder Profile Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              {/* Professional Photo */}
              <div className="text-center lg:text-left">
                <div className="relative inline-block">
                  <div className="w-96 h-96 rounded-2xl overflow-hidden shadow-2xl border-8 border-white">
                    <img
                      src="/lovable-uploads/b5f06ecd-c8e1-4c02-8f84-8c3a882741b1.png"
                      alt="Roshan Gupta - Founder & CEO of ApnaFitness"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -bottom-6 -right-6 bg-blue-600 rounded-xl p-4 shadow-lg">
                    <Award className="h-8 w-8 text-white" />
                  </div>
                </div>
              </div>

              {/* Professional Details */}
              <div className="space-y-8">
                <div className="border-l-4 border-blue-600 pl-6">
                  <h2 className="text-4xl font-bold text-gray-800 mb-2">Roshan Gupta</h2>
                  <p className="text-xl text-blue-600 font-semibold mb-4">Founder & Chief Executive Officer</p>
                  <p className="text-lg text-gray-600">Bachelor of Computer Applications (BCA)</p>
                </div>

                {/* Professional Summary */}
                <div className="bg-gray-50 rounded-xl p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Professional Summary</h3>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    A visionary entrepreneur with a Bachelor's degree in Computer Applications (BCA), Roshan Gupta 
                    combines deep technical expertise with an unwavering passion for fitness industry transformation. 
                    His innovative approach to bridging the gap between qualified fitness professionals and leading 
                    fitness establishments has revolutionized career opportunities across Delhi NCR.
                  </p>
                  <p className="text-gray-700 leading-relaxed">
                    Under his strategic leadership, ApnaFitness has emerged as the premier platform connecting 
                    certified trainers with top-tier gyms and fitness centers, creating a thriving ecosystem 
                    that benefits both fitness professionals and industry leaders.
                  </p>
                </div>

                {/* Key Achievements */}
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-gray-800">Key Achievements</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-sm border">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <span className="text-gray-700">500+ Trainers Placed</span>
                    </div>
                    <div className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-sm border">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <span className="text-gray-700">200+ Partner Gyms</span>
                    </div>
                    <div className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-sm border">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <span className="text-gray-700">95% Success Rate</span>
                    </div>
                    <div className="flex items-center space-x-3 bg-white p-4 rounded-lg shadow-sm border">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <span className="text-gray-700">3 Cities Covered</span>
                    </div>
                  </div>
                </div>

                {/* Connect Section */}
                <div className="pt-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Connect with Roshan</h3>
                  <div className="flex space-x-4">
                    <Button className="bg-blue-600 hover:bg-blue-700 flex items-center space-x-2">
                      <Linkedin className="h-4 w-4" />
                      <span>LinkedIn</span>
                    </Button>
                    <Button variant="outline" className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>Email</span>
                    </Button>
                    <Button variant="outline" className="flex items-center space-x-2">
                      <Twitter className="h-4 w-4" />
                      <span>Twitter</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Mission & Vision</h2>
              <p className="text-xl text-gray-600">Driving innovation in fitness career development</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-xl p-8 shadow-lg border-t-4 border-blue-600">
                <div className="flex items-center mb-6">
                  <Target className="h-8 w-8 text-blue-600 mr-3" />
                  <h3 className="text-2xl font-bold text-blue-600">Our Mission</h3>
                </div>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Revolutionize fitness industry recruitment through technology-driven solutions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Connect qualified fitness professionals with premier career opportunities</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Enable seamless career growth for fitness trainers across Delhi NCR</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Provide gyms with access to top-tier, verified fitness talent</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white rounded-xl p-8 shadow-lg border-t-4 border-green-600">
                <div className="flex items-center mb-6">
                  <Users className="h-8 w-8 text-green-600 mr-3" />
                  <h3 className="text-2xl font-bold text-green-600">Our Vision</h3>
                </div>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Become India's most trusted fitness career platform</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Create a thriving ecosystem where fitness professionals excel</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Establish the gold standard for fitness industry recruitment</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span>Contribute to a healthier, fitter society through quality fitness services</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Core Values */}
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Core Values</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="bg-blue-100 rounded-full p-4 inline-block mb-4">
                    <Award className="h-8 w-8 text-blue-600" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Excellence</h4>
                  <p className="text-gray-600">Commitment to delivering exceptional service and results</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 rounded-full p-4 inline-block mb-4">
                    <Users className="h-8 w-8 text-green-600" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Community</h4>
                  <p className="text-gray-600">Building strong relationships within the fitness ecosystem</p>
                </div>
                <div className="text-center">
                  <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
                    <Target className="h-8 w-8 text-purple-600" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Innovation</h4>
                  <p className="text-gray-600">Continuously evolving to meet industry needs</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Join Roshan's Vision for Fitness Excellence</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Be part of the ApnaFitness revolution and transform your fitness career with industry-leading opportunities
          </p>
          <div className="flex justify-center space-x-4">
            <Link to="/register/trainer">
              <Button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 text-lg">
                Join as Trainer
              </Button>
            </Link>
            <Link to="/post-job">
              <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 text-lg">
                Post a Job
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default MeetFounder;
