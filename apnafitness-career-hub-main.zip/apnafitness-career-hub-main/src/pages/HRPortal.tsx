
import React, { useState } from 'react';
import { Users, Briefcase, TrendingUp, Calendar, Star, MapPin, Phone, Mail, Eye, CheckCircle, X, Filter, Search, Download, Upload, BarChart3, Clock, DollarSign, Building, Award, MessageSquare, FileText, Send, Settings, Bell, Target, Zap, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const HRPortal = () => {
  const [activeTab, setActiveTab] = useState('overview');

  // Enhanced mock data with professional job examples
  const stats = {
    totalJobs: 89,
    activeApplications: 245,
    shortlistedCandidates: 47,
    hiredThisMonth: 18,
    totalViews: 12453,
    conversionRate: '19.2%',
    avgTimeToHire: '12 days',
    topCompanies: 34
  };

  const recentJobs = [
    {
      id: 1,
      title: 'Senior Personal Trainer',
      company: 'Gold's Gym Premium',
      location: 'Delhi, Connaught Place',
      salary: '₹45,000 - ₹65,000/month',
      type: 'Full-time',
      experience: '3-5 years',
      applications: 28,
      views: 456,
      status: 'Active',
      postedDate: '2025-06-03',
      deadline: '2025-06-15',
      urgency: 'High',
      requirements: ['NASM/ACE Certified', 'Weight Training Expert', 'Client Management'],
      description: 'Leading fitness chain seeking experienced personal trainers for premium facility'
    },
    {
      id: 2,
      title: 'Yoga Instructor - Hatha & Vinyasa',
      company: 'Ananda Spa & Resort',
      location: 'Rishikesh, Uttarakhand',
      salary: '₹35,000 - ₹50,000/month',
      type: 'Full-time',
      experience: '2-4 years',
      applications: 34,
      views: 623,
      status: 'Active',
      postedDate: '2025-06-02',
      deadline: '2025-06-12',
      urgency: 'Medium',
      requirements: ['RYT 200+ Certified', 'Multi-style expertise', 'English fluency'],
      description: 'Luxury wellness resort seeking certified yoga instructors for international clientele'
    },
    {
      id: 3,
      title: 'Fitness Manager',
      company: 'Cult.fit Studios',
      location: 'Bangalore, Koramangala',
      salary: '₹60,000 - ₹85,000/month',
      type: 'Full-time',
      experience: '4-6 years',
      applications: 19,
      views: 387,
      status: 'Active',
      postedDate: '2025-06-01',
      deadline: '2025-06-10',
      urgency: 'High',
      requirements: ['Management Experience', 'P&L Responsibility', 'Team Leadership'],
      description: 'Leading fitness chain hiring managers for flagship studio operations'
    }
  ];

  const candidateApplications = [
    {
      id: 1,
      name: 'Roshan Gupta',
      email: 'energiegymmarketing@gmail.com',
      phone: '+919631005476',
      experience: '4 years',
      currentSalary: '₹42,000',
      expectedSalary: '₹55,000',
      skills: ['Personal Training', 'Yoga', 'Pilates', 'Nutrition', 'HIIT'],
      certifications: ['NASM-CPT', 'RYT-200', 'Precision Nutrition L1'],
      jobTitle: 'Senior Personal Trainer',
      company: 'Gold\'s Gym Premium',
      status: 'Under Review',
      appliedDate: '2025-06-03',
      matchScore: 95,
      verified: true,
      location: 'Delhi',
      availability: 'Immediate',
      portfolio: 'Available',
      rating: 4.8,
      clientsHandled: 150,
      specialization: 'Weight Loss & Muscle Building'
    },
    {
      id: 2,
      name: 'Priya Sharma',
      email: 'priya.yoga@email.com',
      phone: '+919876543210',
      experience: '3 years',
      currentSalary: '₹35,000',
      expectedSalary: '₹45,000',
      skills: ['Hatha Yoga', 'Vinyasa', 'Meditation', 'Pranayama', 'Therapeutic Yoga'],
      certifications: ['RYT-500', 'Yin Yoga Certified', 'Meditation Teacher'],
      jobTitle: 'Yoga Instructor - Hatha & Vinyasa',
      company: 'Ananda Spa & Resort',
      status: 'Shortlisted',
      appliedDate: '2025-06-02',
      matchScore: 92,
      verified: true,
      location: 'Rishikesh',
      availability: '2 weeks notice',
      portfolio: 'Available',
      rating: 4.9,
      clientsHandled: 200,
      specialization: 'Therapeutic & Spiritual Yoga'
    },
    {
      id: 3,
      name: 'Arjun Patel',
      email: 'arjun.fitness@email.com',
      phone: '+919988776655',
      experience: '5 years',
      currentSalary: '₹65,000',
      expectedSalary: '₹80,000',
      skills: ['Team Management', 'P&L Management', 'Sales', 'Customer Service', 'Operations'],
      certifications: ['MBA - Operations', 'Fitness Business Certified', 'Leadership Training'],
      jobTitle: 'Fitness Manager',
      company: 'Cult.fit Studios',
      status: 'Interview Scheduled',
      appliedDate: '2025-06-01',
      matchScore: 88,
      verified: true,
      location: 'Bangalore',
      availability: '1 month notice',
      portfolio: 'Available',
      rating: 4.7,
      clientsHandled: 500,
      specialization: 'Operations & Business Management'
    }
  ];

  const analytics = {
    applicationTrends: [
      { month: 'Jan', applications: 180 },
      { month: 'Feb', applications: 220 },
      { month: 'Mar', applications: 195 },
      { month: 'Apr', applications: 245 },
      { month: 'May', applications: 280 },
      { month: 'Jun', applications: 245 }
    ],
    topSkills: [
      { skill: 'Personal Training', demand: 89 },
      { skill: 'Yoga', demand: 76 },
      { skill: 'CrossFit', demand: 54 },
      { skill: 'Pilates', demand: 43 },
      { skill: 'Nutrition', demand: 67 }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Enhanced HR Portal Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-3">HR Enterprise Portal</h1>
              <p className="text-blue-100 text-lg">Advanced Recruitment Management System</p>
              <div className="flex items-center space-x-6 mt-4">
                <div className="flex items-center space-x-2">
                  <Building className="h-5 w-5" />
                  <span>34+ Partner Companies</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>2,450+ Active Candidates</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>19.2% Success Rate</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="bg-white/20 rounded-lg p-4">
                <p className="text-sm opacity-90">Platform Status</p>
                <div className="flex items-center space-x-2 mt-1">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="font-semibold">All Systems Operational</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Enhanced Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>Admin Navigation</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <nav className="space-y-2">
                  {[
                    { id: 'overview', label: 'Dashboard Overview', icon: TrendingUp },
                    { id: 'jobs', label: 'Job Management', icon: Briefcase },
                    { id: 'applications', label: 'Applications', icon: Users },
                    { id: 'candidates', label: 'Candidate Review', icon: Star },
                    { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
                    { id: 'companies', label: 'Company Portal', icon: Building },
                    { id: 'messages', label: 'Communication', icon: MessageSquare }
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center px-4 py-3 rounded-lg transition-all duration-200 ${
                        activeTab === item.id 
                          ? 'bg-blue-600 text-white shadow-lg' 
                          : 'text-gray-600 hover:bg-gray-100 hover:text-blue-600'
                      }`}
                    >
                      <item.icon className="h-5 w-5 mr-3" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  ))}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Enhanced Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Jobs Posted', value: stats.totalJobs, icon: Briefcase, color: 'blue', trend: '+12%' },
                    { label: 'Active Applications', value: stats.activeApplications, icon: Users, color: 'green', trend: '+8%' },
                    { label: 'Candidates Shortlisted', value: stats.shortlistedCandidates, icon: Star, color: 'yellow', trend: '+15%' },
                    { label: 'Successfully Hired', value: stats.hiredThisMonth, icon: CheckCircle, color: 'purple', trend: '+22%' }
                  ].map((stat, index) => (
                    <Card key={index} className="relative overflow-hidden">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                            <p className={`text-3xl font-bold text-${stat.color}-600 mt-1`}>{stat.value}</p>
                            <p className="text-sm text-green-600 font-medium mt-1">{stat.trend} vs last month</p>
                          </div>
                          <div className={`p-3 bg-${stat.color}-100 rounded-full`}>
                            <stat.icon className={`h-8 w-8 text-${stat.color}-600`} />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Zap className="h-6 w-6 text-yellow-500" />
                      <span>Quick Actions</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      {[
                        { label: 'Post New Job', icon: Upload, color: 'blue' },
                        { label: 'Bulk Import CVs', icon: FileText, color: 'green' },
                        { label: 'Send Interviews', icon: Send, color: 'purple' },
                        { label: 'Generate Report', icon: Download, color: 'orange' }
                      ].map((action, index) => (
                        <Button key={index} variant="outline" className="h-20 flex flex-col items-center space-y-2">
                          <action.icon className="h-6 w-6" />
                          <span className="text-sm">{action.label}</span>
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activity */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Recent Job Postings</CardTitle>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      View All Jobs
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentJobs.slice(0, 2).map((job) => (
                        <Card key={job.id} className="border border-gray-200">
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-4">
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 mb-2">
                                  <h4 className="text-xl font-semibold text-gray-800">{job.title}</h4>
                                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                    job.urgency === 'High' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                                  }`}>
                                    {job.urgency} Priority
                                  </span>
                                </div>
                                <p className="text-gray-600 font-medium mb-1">{job.company}</p>
                                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                                  <span className="flex items-center">
                                    <MapPin className="h-4 w-4 mr-1" />
                                    {job.location}
                                  </span>
                                  <span className="flex items-center">
                                    <DollarSign className="h-4 w-4 mr-1" />
                                    {job.salary}
                                  </span>
                                  <span className="flex items-center">
                                    <Clock className="h-4 w-4 mr-1" />
                                    {job.experience}
                                  </span>
                                </div>
                                <p className="text-gray-700 text-sm mb-3">{job.description}</p>
                                <div className="flex flex-wrap gap-2">
                                  {job.requirements.map((req, index) => (
                                    <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                                      {req}
                                    </span>
                                  ))}
                                </div>
                              </div>
                              <div className="text-right ml-6">
                                <span className="px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                                  {job.status}
                                </span>
                                <div className="mt-3 space-y-1 text-sm text-gray-600">
                                  <p>{job.applications} applications</p>
                                  <p>{job.views} views</p>
                                  <p>Expires: {job.deadline}</p>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'jobs' && (
              <div className="space-y-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Job Management Portal</CardTitle>
                      <CardDescription>Manage all your job postings and requirements</CardDescription>
                    </div>
                    <div className="flex space-x-3">
                      <Button variant="outline" className="flex items-center space-x-2">
                        <Filter className="h-4 w-4" />
                        <span>Filter</span>
                      </Button>
                      <Button className="bg-blue-600 hover:bg-blue-700 flex items-center space-x-2">
                        <Upload className="h-4 w-4" />
                        <span>Post New Job</span>
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Job Details</TableHead>
                          <TableHead>Company</TableHead>
                          <TableHead>Applications</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {recentJobs.map((job) => (
                          <TableRow key={job.id}>
                            <TableCell>
                              <div>
                                <p className="font-semibold">{job.title}</p>
                                <p className="text-sm text-gray-600">{job.location}</p>
                                <p className="text-sm text-gray-600">{job.salary}</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <p className="font-medium">{job.company}</p>
                              <p className="text-sm text-gray-600">{job.type}</p>
                            </TableCell>
                            <TableCell>
                              <div className="text-center">
                                <p className="text-lg font-bold text-blue-600">{job.applications}</p>
                                <p className="text-xs text-gray-600">{job.views} views</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                                {job.status}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button size="sm" variant="outline">View</Button>
                                <Button size="sm" variant="outline">Edit</Button>
                                <Button size="sm" variant="outline" className="text-red-600">Close</Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'applications' && (
              <div className="space-y-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Application Management</CardTitle>
                      <CardDescription>Review and manage candidate applications</CardDescription>
                    </div>
                    <div className="flex space-x-3">
                      <Button variant="outline" className="flex items-center space-x-2">
                        <Search className="h-4 w-4" />
                        <span>Search</span>
                      </Button>
                      <Button variant="outline" className="flex items-center space-x-2">
                        <Download className="h-4 w-4" />
                        <span>Export</span>
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {candidateApplications.map((candidate) => (
                        <Card key={candidate.id} className="border border-gray-200">
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-6">
                              <div className="flex items-start space-x-4">
                                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                                  <span className="text-white font-bold text-lg">
                                    {candidate.name.split(' ').map(n => n[0]).join('')}
                                  </span>
                                </div>
                                <div>
                                  <h3 className="text-xl font-semibold text-gray-800 flex items-center">
                                    {candidate.name}
                                    {candidate.verified && (
                                      <Award className="h-5 w-5 text-yellow-500 ml-2" />
                                    )}
                                  </h3>
                                  <p className="text-gray-600 font-medium">{candidate.jobTitle}</p>
                                  <p className="text-sm text-gray-500">{candidate.company}</p>
                                  <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                                    <span className="flex items-center">
                                      <Mail className="h-4 w-4 mr-1" />
                                      {candidate.email}
                                    </span>
                                    <span className="flex items-center">
                                      <Phone className="h-4 w-4 mr-1" />
                                      {candidate.phone}
                                    </span>
                                    <span className="flex items-center">
                                      <MapPin className="h-4 w-4 mr-1" />
                                      {candidate.location}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className={`px-4 py-2 rounded-full text-sm font-medium ${
                                  candidate.status === 'Shortlisted' ? 'bg-green-100 text-green-800' :
                                  candidate.status === 'Interview Scheduled' ? 'bg-blue-100 text-blue-800' :
                                  candidate.status === 'Under Review' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-gray-100 text-gray-800'
                                }`}>
                                  {candidate.status}
                                </span>
                                <div className="mt-2 text-sm text-gray-600">
                                  <p>{candidate.matchScore}% Match</p>
                                  <p>Rating: {candidate.rating}/5</p>
                                </div>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                              <div>
                                <h4 className="font-semibold text-gray-800 mb-2">Experience & Salary</h4>
                                <p className="text-sm text-gray-600">Experience: {candidate.experience}</p>
                                <p className="text-sm text-gray-600">Current: {candidate.currentSalary}</p>
                                <p className="text-sm text-gray-600">Expected: {candidate.expectedSalary}</p>
                                <p className="text-sm text-gray-600">Availability: {candidate.availability}</p>
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-800 mb-2">Skills & Specialization</h4>
                                <div className="flex flex-wrap gap-1 mb-2">
                                  {candidate.skills.slice(0, 3).map((skill, index) => (
                                    <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                                      {skill}
                                    </span>
                                  ))}
                                </div>
                                <p className="text-sm text-gray-600">{candidate.specialization}</p>
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-800 mb-2">Achievements</h4>
                                <p className="text-sm text-gray-600">Clients Handled: {candidate.clientsHandled}</p>
                                <p className="text-sm text-gray-600">Portfolio: {candidate.portfolio}</p>
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {candidate.certifications.slice(0, 2).map((cert, index) => (
                                    <span key={index} className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                                      {cert}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-3">
                              <Button className="bg-green-600 hover:bg-green-700 flex items-center space-x-2">
                                <CheckCircle className="h-4 w-4" />
                                <span>Shortlist</span>
                              </Button>
                              <Button variant="outline" className="flex items-center space-x-2">
                                <Calendar className="h-4 w-4" />
                                <span>Schedule Interview</span>
                              </Button>
                              <Button variant="outline" className="flex items-center space-x-2">
                                <MessageSquare className="h-4 w-4" />
                                <span>Send Message</span>
                              </Button>
                              <Button variant="outline" className="flex items-center space-x-2">
                                <Eye className="h-4 w-4" />
                                <span>View Full Profile</span>
                              </Button>
                              <Button variant="outline" className="text-red-600 border-red-600 hover:bg-red-50 flex items-center space-x-2">
                                <X className="h-4 w-4" />
                                <span>Reject</span>
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'candidates' && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Candidate Review & Assessment</CardTitle>
                    <CardDescription>Detailed candidate profiles with reviews and ratings</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {candidateApplications.map((candidate) => (
                        <Card key={candidate.id} className="border border-gray-200">
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <h3 className="text-xl font-semibold text-gray-800">{candidate.name}</h3>
                                <p className="text-gray-600">{candidate.jobTitle}</p>
                                <p className="text-sm text-gray-500">{candidate.specialization}</p>
                              </div>
                              <div className="text-right">
                                <div className="flex items-center space-x-1 mb-2">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star key={star} className={`h-5 w-5 ${star <= candidate.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} />
                                  ))}
                                  <span className="text-sm text-gray-600 ml-2">{candidate.rating}/5</span>
                                </div>
                                <p className="text-sm text-gray-600">Based on {candidate.clientsHandled} clients</p>
                              </div>
                            </div>

                            <div className="bg-gray-50 rounded-lg p-4 mb-4">
                              <h4 className="font-semibold text-gray-800 mb-3">Latest Client Reviews</h4>
                              <div className="space-y-3">
                                <div className="bg-white rounded p-3">
                                  <p className="text-gray-700 text-sm mb-2">
                                    "Excellent trainer with great knowledge of fitness and nutrition. Very professional 
                                    and dedicated to helping clients achieve their goals. Highly recommended!"
                                  </p>
                                  <p className="text-xs text-gray-500">- Gold's Gym Client • 1 week ago</p>
                                </div>
                                <div className="bg-white rounded p-3">
                                  <p className="text-gray-700 text-sm mb-2">
                                    "Amazing yoga instructor! Very patient and skilled. Helped me improve my flexibility 
                                    and reduce stress significantly."
                                  </p>
                                  <p className="text-xs text-gray-500">- Wellness Center Client • 2 weeks ago</p>
                                </div>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div>
                                <h4 className="font-semibold text-gray-800 mb-2">Professional Metrics</h4>
                                <div className="space-y-1 text-sm">
                                  <p>Client Retention Rate: 92%</p>
                                  <p>Session Completion: 98%</p>
                                  <p>Goal Achievement: 85%</p>
                                  <p>Punctuality Score: 96%</p>
                                </div>
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-800 mb-2">Background Check</h4>
                                <div className="space-y-1 text-sm">
                                  <p className="flex items-center text-green-600">
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    Identity Verified
                                  </p>
                                  <p className="flex items-center text-green-600">
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    Certificates Valid
                                  </p>
                                  <p className="flex items-center text-green-600">
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    Criminal Record Clean
                                  </p>
                                  <p className="flex items-center text-green-600">
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                    References Verified
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="flex space-x-3">
                              <Button className="bg-blue-600 hover:bg-blue-700">
                                View Complete Profile
                              </Button>
                              <Button variant="outline">
                                Schedule Video Interview
                              </Button>
                              <Button variant="outline">
                                Contact References
                              </Button>
                              <Button variant="outline">
                                Download Resume
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BarChart3 className="h-6 w-6" />
                      <span>Advanced Analytics & Insights</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
                        <h3 className="font-semibold text-gray-800 mb-4">Hiring Performance</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span>Time to Hire</span>
                            <span className="font-semibold">12 days</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Cost per Hire</span>
                            <span className="font-semibold">₹8,500</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Success Rate</span>
                            <span className="font-semibold text-green-600">19.2%</span>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6">
                        <h3 className="font-semibold text-gray-800 mb-4">Platform Engagement</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span>Daily Active Users</span>
                            <span className="font-semibold">1,245</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Job Views</span>
                            <span className="font-semibold">12,453</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Application Rate</span>
                            <span className="font-semibold text-blue-600">23.8%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default HRPortal;
