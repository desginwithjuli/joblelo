
import React, { useState } from 'react';
import { Search, MapPin, Filter, Clock, DollarSign, Building, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const jobPostings = [
  {
    id: 1,
    title: "Zumba Instructor",
    gym: "Energie Gym",
    location: "Noida, Sector 18",
    salary: "₹30,000 - ₹40,000/month",
    experience: "2+ years",
    type: "Full-time",
    posted: "2 days ago",
    requirements: ["ZIN certification", "Evening availability", "Group fitness experience"],
    description: "Seeking a certified Zumba instructor for evening classes. Competitive pay and flexible hours."
  },
  {
    id: 2,
    title: "CrossFit Coach",
    gym: "Cult Fit",
    location: "Delhi, Connaught Place",
    salary: "₹35,000 - ₹50,000/month",
    experience: "3+ years",
    type: "Full-time",
    posted: "1 day ago",
    requirements: ["Level 1 CrossFit certification", "HIIT training experience", "CPR certified"],
    description: "Lead high-intensity CrossFit sessions for our premium members. Great team environment."
  },
  {
    id: 3,
    title: "Personal Trainer",
    gym: "Gold's Gym",
    location: "Ghaziabad, Indirapuram",
    salary: "₹25,000 - ₹45,000/month",
    experience: "1-3 years",
    type: "Full-time",
    posted: "3 days ago",
    requirements: ["ISSA/ACE certification", "Client relationship skills", "Nutrition knowledge"],
    description: "Hiring a certified personal trainer for one-on-one client sessions. Commission opportunities available."
  },
  {
    id: 4,
    title: "Yoga Instructor",
    gym: "21 Fitness",
    location: "Delhi, Saket",
    salary: "₹20,000 - ₹30,000/month",
    experience: "2+ years",
    type: "Part-time",
    posted: "4 days ago",
    requirements: ["Yoga Alliance certification", "Hatha & Vinyasa expertise", "Morning/evening availability"],
    description: "Teach Hatha and Vinyasa yoga for morning and evening batches. Peaceful studio environment."
  },
  {
    id: 5,
    title: "Group Fitness Trainer",
    gym: "Father of Fitness",
    location: "Noida, Sector 62",
    salary: "₹28,000 - ₹38,000/month",
    experience: "2+ years",
    type: "Full-time",
    posted: "5 days ago",
    requirements: ["Any recognized fitness certification", "Group class experience", "High energy personality"],
    description: "Lead HIIT and aerobics classes for diverse groups. Growing fitness community."
  },
  {
    id: 6,
    title: "Strength Training Coach",
    gym: "Anytime Fitness",
    location: "Delhi, Lajpat Nagar",
    salary: "₹32,000 - ₹42,000/month",
    experience: "3+ years",
    type: "Full-time",
    posted: "1 week ago",
    requirements: ["NASM/ACSM certification", "Powerlifting experience", "24/7 availability"],
    description: "Specialized strength training coach for our 24/7 fitness center. Equipment expertise required."
  }
];

const Jobs = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedExperience, setSelectedExperience] = useState('');

  const filteredJobs = jobPostings.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.gym.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLocation = !selectedLocation || job.location.includes(selectedLocation);
    const matchesExperience = !selectedExperience || job.experience.includes(selectedExperience);
    
    return matchesSearch && matchesLocation && matchesExperience;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Search Section */}
      <section className="bg-white shadow-sm border-b py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Find Your Perfect Fitness Job</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search jobs, skills, or gym names..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select 
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2"
            >
              <option value="">All Locations</option>
              <option value="Delhi">Delhi</option>
              <option value="Ghaziabad">Ghaziabad</option>
              <option value="Noida">Noida</option>
            </select>
            <select 
              value={selectedExperience}
              onChange={(e) => setSelectedExperience(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2"
            >
              <option value="">All Experience</option>
              <option value="1">1+ years</option>
              <option value="2">2+ years</option>
              <option value="3">3+ years</option>
            </select>
          </div>
          
          <div className="mt-4 text-gray-600">
            Showing {filteredJobs.length} of {jobPostings.length} jobs
          </div>
        </div>
      </section>

      {/* Jobs List */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="space-y-6">
            {filteredJobs.map((job) => (
              <div key={job.id} className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{job.title}</h3>
                    <div className="flex items-center space-x-4 text-gray-600 mb-2">
                      <div className="flex items-center">
                        <Building className="h-4 w-4 mr-1" />
                        <span>{job.gym}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{job.location}</span>
                      </div>
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 mr-1" />
                        <span>{job.salary}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                      <span>{job.type}</span>
                      <span>•</span>
                      <span>{job.experience} experience</span>
                      <span>•</span>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{job.posted}</span>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Apply Now
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
                
                <p className="text-gray-700 mb-4">{job.description}</p>
                
                <div className="border-t pt-4">
                  <div className="text-sm font-semibold text-gray-700 mb-2">Requirements:</div>
                  <div className="flex flex-wrap gap-2">
                    {job.requirements.map((req, index) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                        {req}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Jobs;
