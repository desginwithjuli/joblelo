
import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Award, Upload, CheckCircle, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const TrainerRegister = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    experience: '',
    certifications: [],
    skills: [],
    preferredLocations: [],
    bio: ''
  });

  const [isRegistered, setIsRegistered] = useState(false);
  const [credentials, setCredentials] = useState({
    username: '',
    password: ''
  });

  const skillOptions = [
    'Personal Training', 'Yoga', 'Zumba', 'CrossFit', 'HIIT', 'Pilates', 
    'Aerobics', 'Strength Training', 'Cardio', 'Nutrition Counseling',
    'Weight Loss', 'Muscle Building', 'Functional Training', 'Boxing'
  ];

  const locationOptions = ['Delhi', 'Ghaziabad', 'Noida'];

  const handleSkillToggle = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.includes(skill) 
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }));
  };

  const handleLocationToggle = (location: string) => {
    setFormData(prev => ({
      ...prev,
      preferredLocations: prev.preferredLocations.includes(location)
        ? prev.preferredLocations.filter(l => l !== location)
        : [...prev.preferredLocations, location]
    }));
  };

  const generateCredentials = () => {
    const username = `${formData.firstName}_${formData.lastName}_${Math.floor(Math.random() * 9999)}`;
    const password = `${formData.firstName}${Math.floor(Math.random() * 999)}!`;
    return { username, password };
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Trainer registration data:', formData);
    
    // Generate credentials
    const newCredentials = generateCredentials();
    setCredentials(newCredentials);
    setIsRegistered(true);
    
    // Here we would typically send the data to the backend
    console.log('Generated credentials:', newCredentials);
  };

  if (isRegistered) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        
        <section className="py-16">
          <div className="container mx-auto px-4 max-w-2xl">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-white" />
              </div>
              
              <h1 className="text-3xl font-bold text-gray-800 mb-4">Registration Successful!</h1>
              <p className="text-gray-600 mb-8">
                Welcome to ApnaFitness! Your trainer profile has been created successfully.
              </p>

              <div className="bg-blue-50 rounded-lg p-6 mb-8">
                <h2 className="text-xl font-bold text-blue-800 mb-4">Your Login Credentials</h2>
                <p className="text-sm text-blue-700 mb-4">
                  Please save these credentials safely. You'll need them to access your dashboard.
                </p>
                
                <div className="space-y-4">
                  <div className="bg-white rounded-lg p-4 border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div className="text-left">
                        <p className="text-sm font-medium text-gray-600">Username</p>
                        <p className="text-lg font-bold text-gray-800">{credentials.username}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(credentials.username)}
                        className="flex items-center space-x-1"
                      >
                        <Copy className="h-4 w-4" />
                        <span>Copy</span>
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg p-4 border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div className="text-left">
                        <p className="text-sm font-medium text-gray-600">Temporary Password</p>
                        <p className="text-lg font-bold text-gray-800">{credentials.password}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(credentials.password)}
                        className="flex items-center space-x-1"
                      >
                        <Copy className="h-4 w-4" />
                        <span>Copy</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-yellow-800 mb-2">Important Notes:</h3>
                <ul className="text-sm text-yellow-700 space-y-1 text-left">
                  <li>• Your credentials have been sent to your email: {formData.email}</li>
                  <li>• Please change your password after your first login</li>
                  <li>• Keep your credentials secure and don't share them</li>
                  <li>• You can now access your dashboard and start applying for jobs</li>
                </ul>
              </div>

              <div className="space-y-4">
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 py-3 text-lg"
                  onClick={() => window.location.href = '/login'}
                >
                  Login to Dashboard
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full py-3"
                  onClick={() => window.location.href = '/jobs'}
                >
                  Browse Jobs
                </Button>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">Join as a Fitness Trainer</h1>
            <p className="text-xl text-gray-600">
              Create your profile and get matched with top gyms across Delhi NCR
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                      placeholder="Enter your first name"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="lastName">Last Name *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                      placeholder="Enter your last name"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="your.email@example.com"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      placeholder="+91 98765 43210"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Experience */}
              <div>
                <Label htmlFor="experience">Years of Experience *</Label>
                <select 
                  id="experience"
                  value={formData.experience}
                  onChange={(e) => setFormData({...formData, experience: e.target.value})}
                  className="w-full border border-gray-300 rounded-md px-3 py-2"
                  required
                >
                  <option value="">Select your experience level</option>
                  <option value="0-1">0-1 years</option>
                  <option value="1-2">1-2 years</option>
                  <option value="2-5">2-5 years</option>
                  <option value="5-10">5-10 years</option>
                  <option value="10+">10+ years</option>
                </select>
              </div>

              {/* Skills */}
              <div>
                <Label>Skills & Specializations *</Label>
                <p className="text-sm text-gray-600 mb-3">Select all that apply to your expertise</p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {skillOptions.map((skill) => (
                    <div
                      key={skill}
                      onClick={() => handleSkillToggle(skill)}
                      className={`cursor-pointer p-3 rounded-lg border text-center transition-colors ${
                        formData.skills.includes(skill)
                          ? 'bg-blue-100 border-blue-500 text-blue-700'
                          : 'bg-gray-50 border-gray-300 hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-sm font-medium">{skill}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Preferred Locations */}
              <div>
                <Label>Preferred Work Locations *</Label>
                <p className="text-sm text-gray-600 mb-3">Choose where you'd like to work</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {locationOptions.map((location) => (
                    <div
                      key={location}
                      onClick={() => handleLocationToggle(location)}
                      className={`cursor-pointer p-4 rounded-lg border text-center transition-colors ${
                        formData.preferredLocations.includes(location)
                          ? 'bg-green-100 border-green-500 text-green-700'
                          : 'bg-gray-50 border-gray-300 hover:bg-gray-100'
                      }`}
                    >
                      <MapPin className="h-5 w-5 mx-auto mb-2" />
                      <span className="font-medium">{location}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bio */}
              <div>
                <Label htmlFor="bio">Professional Bio</Label>
                <textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => setFormData({...formData, bio: e.target.value})}
                  placeholder="Tell us about your fitness journey, training philosophy, and what makes you unique as a trainer..."
                  className="w-full border border-gray-300 rounded-md px-3 py-2 h-24 resize-none"
                />
              </div>

              {/* Certification Upload */}
              <div>
                <Label>Upload Certifications</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-600 mb-2">Upload your fitness certifications</p>
                  <p className="text-sm text-gray-500">PNG, JPG, PDF up to 10MB each</p>
                  <Button type="button" variant="outline" className="mt-3">
                    Choose Files
                  </Button>
                </div>
              </div>

              {/* Terms */}
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="terms" required className="rounded" />
                <label htmlFor="terms" className="text-sm text-gray-600">
                  I agree to the <a href="/terms" className="text-blue-600 hover:underline">Terms of Service</a> and 
                  <a href="/privacy" className="text-blue-600 hover:underline ml-1">Privacy Policy</a>
                </label>
              </div>

              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 py-3 text-lg">
                Create My Trainer Profile
              </Button>
            </form>

            <div className="mt-6 p-4 bg-green-50 rounded-lg">
              <h3 className="font-semibold text-green-800 mb-2">What happens next?</h3>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• We'll generate your unique login credentials</li>
                <li>• Login details will be sent to your email</li>
                <li>• You can immediately start browsing and applying for jobs</li>
                <li>• Our AI will recommend relevant opportunities based on your profile</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default TrainerRegister;
