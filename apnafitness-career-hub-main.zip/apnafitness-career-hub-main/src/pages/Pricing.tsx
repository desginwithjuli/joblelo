
import React from 'react';
import { Check, Star, Crown, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const pricingPlans = [
  {
    name: "Basic",
    price: "₹499",
    period: "/month",
    icon: <Star className="h-6 w-6" />,
    description: "Perfect for small gyms getting started",
    features: [
      "Post up to 3 jobs",
      "View 10 applications per job",
      "Basic analytics",
      "Email support",
      "Standard job listing visibility",
      "Basic candidate filters"
    ],
    limitations: [
      "Limited to 3 active job postings",
      "No AI recommendations",
      "Standard support only"
    ],
    buttonText: "Start Basic Plan",
    popular: false,
    color: "blue"
  },
  {
    name: "Pro",
    price: "₹999",
    period: "/month",
    icon: <Zap className="h-6 w-6" />,
    description: "Best for growing fitness businesses",
    features: [
      "Post up to 10 jobs",
      "Unlimited applications",
      "Priority job listing",
      "AI-recommended candidates",
      "Advanced analytics",
      "Priority email support",
      "Candidate screening tools",
      "Custom job branding"
    ],
    limitations: [],
    buttonText: "Choose Pro Plan",
    popular: true,
    color: "green"
  },
  {
    name: "Premium",
    price: "₹1,999",
    period: "/month",
    icon: <Crown className="h-6 w-6" />,
    description: "For large chains and premium gyms",
    features: [
      "Unlimited job postings",
      "AI-driven candidate matching",
      "Dedicated account manager",
      "Advanced analytics dashboard",
      "Custom integration support",
      "Phone & email support",
      "Bulk operations",
      "White-label solutions",
      "Priority candidate access",
      "Multi-location management"
    ],
    limitations: [],
    buttonText: "Get Premium",
    popular: false,
    color: "purple"
  }
];

const Pricing = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Choose Your Perfect Plan</h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Find the right plan for your gym's hiring needs. All plans include access to our extensive trainer network.
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-xl shadow-lg overflow-hidden ${
                  plan.popular ? 'ring-2 ring-green-500 transform scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <div className="bg-green-500 text-white text-center py-2 font-semibold">
                    Most Popular
                  </div>
                )}
                
                <div className="p-8">
                  <div className="flex items-center justify-center mb-4">
                    <div className={`p-3 rounded-full ${
                      plan.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                      plan.color === 'green' ? 'bg-green-100 text-green-600' :
                      'bg-purple-100 text-purple-600'
                    }`}>
                      {plan.icon}
                    </div>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-center mb-2">{plan.name}</h3>
                  <p className="text-gray-600 text-center mb-6">{plan.description}</p>
                  
                  <div className="text-center mb-8">
                    <span className="text-4xl font-bold text-gray-800">{plan.price}</span>
                    <span className="text-gray-600">{plan.period}</span>
                  </div>
                  
                  <Button 
                    className={`w-full mb-6 ${
                      plan.popular ? 'bg-green-600 hover:bg-green-700' : 
                      plan.color === 'blue' ? 'bg-blue-600 hover:bg-blue-700' :
                      'bg-purple-600 hover:bg-purple-700'
                    }`}
                  >
                    {plan.buttonText}
                  </Button>
                  
                  <div className="space-y-3">
                    <h4 className="font-semibold text-gray-800 mb-3">What's included:</h4>
                    {plan.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center">
                        <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* FAQ Section */}
          <div className="mt-16 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">Can I upgrade or downgrade my plan?</h3>
                <p className="text-gray-600">Yes, you can change your plan anytime. Upgrades take effect immediately, while downgrades apply at your next billing cycle.</p>
              </div>
              
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">Is there a setup fee?</h3>
                <p className="text-gray-600">No setup fees! Just pay your monthly subscription and start posting jobs immediately.</p>
              </div>
              
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">What payment methods do you accept?</h3>
                <p className="text-gray-600">We accept all major credit cards, debit cards, and UPI payments through our secure Razorpay integration.</p>
              </div>
              
              <div className="bg-white rounded-lg p-6 shadow-md">
                <h3 className="text-lg font-semibold mb-2">Can I cancel anytime?</h3>
                <p className="text-gray-600">Yes, you can cancel your subscription anytime. Your plan remains active until the end of your current billing period.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Pricing;
