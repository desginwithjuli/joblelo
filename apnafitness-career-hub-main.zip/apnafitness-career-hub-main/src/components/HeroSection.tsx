
import React, { useState } from 'react';
import { Search, MapPin, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const HeroSection = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');

  return (
    <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl font-bold mb-6">
          Your Fitness Career, <span className="text-green-400">One Click Away</span>
        </h1>
        <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
          Connecting certified fitness trainers with top gyms across Delhi, Ghaziabad & Noida. 
          Find your dream job or hire the perfect trainer today.
        </p>

        {/* Search Bar */}
        <div className="bg-white rounded-lg p-6 shadow-xl max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search for jobs, skills, or gym names..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-gray-700"
              />
            </div>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <select className="w-full h-12 pl-10 pr-4 border border-gray-300 rounded-md text-gray-700 bg-white">
                <option value="">All Locations</option>
                <option value="delhi">Delhi</option>
                <option value="ghaziabad">Ghaziabad</option>
                <option value="noida">Noida</option>
              </select>
            </div>
            <Button className="h-12 bg-green-500 hover:bg-green-600 text-white font-semibold">
              Search Jobs
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400">500+</div>
            <div className="text-blue-100">Active Job Postings</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400">200+</div>
            <div className="text-blue-100">Partner Gyms</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400">1000+</div>
            <div className="text-blue-100">Registered Trainers</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
