
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Users, Building } from 'lucide-react';

const CTASection = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-green-500 to-green-600 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-4xl font-bold mb-6">Ready to Transform Your Fitness Career?</h2>
        <p className="text-xl mb-12 text-green-100 max-w-2xl mx-auto">
          Join thousands of fitness professionals and gym owners who are already part of the ApnaFitness community
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* For Trainers */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8">
            <Users className="h-12 w-12 mx-auto mb-4 text-green-200" />
            <h3 className="text-2xl font-bold mb-4">For Fitness Trainers</h3>
            <p className="text-green-100 mb-6">
              Discover exciting job opportunities at top gyms across Delhi NCR. Get matched with positions that fit your skills perfectly.
            </p>
            <Link to="/register/trainer">
              <Button className="bg-white text-green-600 hover:bg-gray-100 font-semibold px-8 py-3">
                Find Your Dream Job
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>

          {/* For Gym Owners */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8">
            <Building className="h-12 w-12 mx-auto mb-4 text-green-200" />
            <h3 className="text-2xl font-bold mb-4">For Gym Owners</h3>
            <p className="text-green-100 mb-6">
              Connect with certified trainers who match your requirements. Post jobs and find the perfect addition to your team.
            </p>
            <Link to="/register/gym">
              <Button className="bg-white text-green-600 hover:bg-gray-100 font-semibold px-8 py-3">
                Hire Top Talent
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
