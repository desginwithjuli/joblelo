
import React from 'react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: "Priya Sharma",
    role: "Yoga Instructor",
    gym: "Cult Fit, Delhi",
    rating: 5,
    text: "ApnaFitness helped me find my dream job at Cult Fit. The platform is so easy to use and I got matched with the perfect opportunity!"
  },
  {
    name: "Rajesh Kumar",
    role: "CrossFit Coach",
    gym: "Gold's Gym, Ghaziabad",
    rating: 5,
    text: "As a gym owner, finding qualified trainers was always a challenge. ApnaFitness made it simple to connect with certified professionals."
  },
  {
    name: "Ankita Singh",
    role: "Personal Trainer",
    gym: "Energie Gym, Noida",
    rating: 5,
    text: "The AI-powered job matching is incredible! I received relevant job recommendations that perfectly matched my skills and location preferences."
  }
];

const TestimonialsSection = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">What Our Community Says</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Hear from trainers and gym owners who've found success through ApnaFitness
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Quote className="h-8 w-8 text-blue-600 mr-3" />
                <div className="flex">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
              </div>
              
              <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
              
              <div className="border-t pt-4">
                <div className="font-semibold text-gray-800">{testimonial.name}</div>
                <div className="text-sm text-gray-600">{testimonial.role}</div>
                <div className="text-sm text-blue-600">{testimonial.gym}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
