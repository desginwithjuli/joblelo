
import React from 'react';
import { MapPin, Briefcase } from 'lucide-react';

const featuredGyms = [
  {
    name: "Energie Gym",
    location: "Noida, Sector 18",
    logo: "🏋️",
    activeJobs: 12,
    description: "Premium fitness chain with state-of-the-art equipment"
  },
  {
    name: "Cult Fit",
    location: "Delhi, Connaught Place",
    logo: "💪",
    activeJobs: 18,
    description: "India's largest fitness community platform"
  },
  {
    name: "Gold's Gym",
    location: "Ghaziabad, Indirapuram",
    logo: "🥇",
    activeJobs: 15,
    description: "World's most recognized fitness brand"
  },
  {
    name: "21 Fitness",
    location: "Delhi, Saket",
    logo: "🔥",
    activeJobs: 8,
    description: "Modern fitness studio with diverse workout programs"
  },
  {
    name: "Father of Fitness",
    location: "Noida, Sector 62",
    logo: "💯",
    activeJobs: 10,
    description: "Community-focused gym with personal training excellence"
  },
  {
    name: "Anytime Fitness",
    location: "Delhi, Lajpat Nagar",
    logo: "⏰",
    activeJobs: 6,
    description: "24/7 access fitness centers worldwide"
  }
];

const FeaturedGyms = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Featured Partner Gyms</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Join the network of top fitness centers across Delhi NCR that trust ApnaFitness for their hiring needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredGyms.map((gym, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow p-6">
              <div className="flex items-center mb-4">
                <div className="text-4xl mr-4">{gym.logo}</div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800">{gym.name}</h3>
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="text-sm">{gym.location}</span>
                  </div>
                </div>
              </div>
              
              <p className="text-gray-600 mb-4">{gym.description}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-green-600">
                  <Briefcase className="h-4 w-4 mr-1" />
                  <span className="font-semibold">{gym.activeJobs} Active Jobs</span>
                </div>
                <button className="text-blue-600 hover:text-blue-800 font-medium">
                  View Jobs →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedGyms;
