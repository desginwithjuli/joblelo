
import React from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, User, LogIn, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  return (
    <header className="bg-white shadow-md border-b border-gray-200">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Dumbbell className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-800">ApnaFitness</span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/jobs" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Find Jobs
            </Link>
            <Link to="/post-job" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Post Jobs
            </Link>
            <Link to="/pricing" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Pricing
            </Link>
            <Link to="/about" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              About
            </Link>
            <Link to="/meet-founder" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Meet Founder
            </Link>
            <Link to="/hr-portal" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
              Check Demo
            </Link>
          </nav>

          {/* Auth Buttons */}
          <div className="flex items-center space-x-3">
            <Link to="/login">
              <Button variant="outline" className="flex items-center space-x-2">
                <LogIn className="h-4 w-4" />
                <span>Login</span>
              </Button>
            </Link>
            <Link to="/register/trainer">
              <Button className="bg-blue-600 hover:bg-blue-700 flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Sign Up</span>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
