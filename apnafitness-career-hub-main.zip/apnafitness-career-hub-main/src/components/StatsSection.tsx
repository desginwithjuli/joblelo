
import React from 'react';
import { TrendingUp, Users, Award, Clock } from 'lucide-react';

const StatsSection = () => {
  const stats = [
    {
      icon: <Users className="h-8 w-8" />,
      number: "1,000+",
      label: "Registered Trainers",
      description: "Certified fitness professionals"
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      number: "500+",
      label: "Jobs Posted",
      description: "Active opportunities available"
    },
    {
      icon: <Award className="h-8 w-8" />,
      number: "200+",
      label: "Partner Gyms",
      description: "Trusted fitness centers"
    },
    {
      icon: <Clock className="h-8 w-8" />,
      number: "24/7",
      label: "Platform Access",
      description: "Find jobs anytime, anywhere"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Making Fitness Careers Happen
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our platform connects the best fitness talent with leading gyms across Delhi NCR
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4">
                {stat.icon}
              </div>
              <div className="text-3xl font-bold text-gray-800 mb-2">{stat.number}</div>
              <div className="text-lg font-semibold text-gray-700 mb-1">{stat.label}</div>
              <div className="text-gray-600">{stat.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
